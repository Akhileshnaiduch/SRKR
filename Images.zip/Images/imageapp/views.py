from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'imageapp\home.html')

# from imageapp.forms import UserImageForm    
# from .models import UploadImage  


# def image(request):  
#     if request.method == 'POST':  
#         form = UserImageForm(request.POST, request.FILES)  
#         if form.is_valid():  
#             form.save()  
#             img_object = form.instance                
#             return render(request, 'image_form.html', {'form': form, 'img_obj': img_object})  
#     else:  
#         form = UserImageForm()  
  
#     return render(request, 'imageapp\imageupload.html', {'form': form}) 
#
# for uploading images. 

from django.shortcuts import render
from .forms import ImageForm
from .models import Image


def image(request):
    """Process images uploaded by users"""
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            # Get the current instance object to display in the template
            img_obj = form.instance
            return render(request, 'imageapp\imageupload.html', {'form': form, 'img_obj': img_obj})
    else:
        form = ImageForm()
    return render(request, 'imageapp\imageupload.html', {'form': form})

def images(request):
    all_images=Image.objects.all()
    context={'all_images':all_images}
    return render(request, 'imageapp\image.html', context)

